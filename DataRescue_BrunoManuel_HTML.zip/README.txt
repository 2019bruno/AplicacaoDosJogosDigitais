
DataRescue – Missão Segurança Digital
====================================

Este pacote é uma versão OFFLINE e auto-contenida do Interactive Book 'DataRescue'.
Contém:
 - index.html : o Interactive Book com capítulos e quizzes (em Português).
 - assets/     : pasta para colocar imagens ou vídeo caso deseje substituir.

Como usar:
 - Descompacte o ficheiro e abra index.html num browser moderno (Chrome/Firefox).
 - Para converter para SCORM/H5P oficiais: importe o conteúdo manualmente no LUMI e utilize o editor H5P para inserir o mesmo conteúdo (ou crie um novo Interactive Book e cole o texto).
 - Alternativamente, pode hospedar a pasta em GitHub Pages/Netlify e usar o link no Moodle (recomendo SCORM para registo de pontuações).

Nota:
 - Este ficheiro NÃO é um .h5p nem um pacote SCORM válido. A criação de um .h5p/SCORM oficial requer LUMI/H5P export e não é possível completar totalmente neste ambiente.
 - Forneço o conteúdo textual e a versão HTML funcional para facilitar a importação e a criação do pacote final no seu computador.

Passos sugeridos para gerar SCORM com LUMI:
 1) Abra LUMI -> New project -> Escolha Interactive Book.
 2) Copie/cole o conteúdo dos capítulos e as perguntas para o editor H5P.
 3) Insira a imagem de capa e video (substitua no editor).
 4) Export -> SCORM Package (.zip)
 5) Carregue o SCORM .zip no Moodle como "SCORM package".

Autor: Bruno Manuel
